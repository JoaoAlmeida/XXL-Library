/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package util.sse;

/**
 *
 * @author joao
 */
public interface Parser {

    /**
     * Build a document vector from the document id and text given.
     * @param documentId
     * @param txt
     * @return
     */
     
    public Vector parse(int documentId, String txt);
}

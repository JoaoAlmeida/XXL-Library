/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package util.rtree;

/**
 *
 * @author joao
 */
public interface AggField<K>{

   public K getAggValue();

   public void setAggValue(K value);
}

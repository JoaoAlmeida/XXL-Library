package util.experiment;

import java.util.Properties;

/**
 *
 * @author joao
 */
public interface ExperimentFactory {

    public ExperimentManager produce(Properties props, int round);
}

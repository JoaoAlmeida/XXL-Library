/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package util.tuples;


/**
 *
 * @author joao
 */
public interface TupleFactory {

    public Tuple produce();

    public Cell[] getClustersMBRs();
}

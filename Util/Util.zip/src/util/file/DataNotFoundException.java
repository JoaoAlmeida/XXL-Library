package util.file;

public class DataNotFoundException extends Exception {

    public DataNotFoundException() {
        super();
    }

    public DataNotFoundException(String message) {
        super(message);
    }

    public DataNotFoundException(Throwable detail) {
        super(detail);
    }

    public DataNotFoundException(String message, Throwable detail) {
        super(message, detail);
    }

}
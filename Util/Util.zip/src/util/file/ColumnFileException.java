package util.file;

public class ColumnFileException extends Exception {

    public ColumnFileException() {
        super();
    }

    public ColumnFileException(String message) {
        super(message);
    }

    public ColumnFileException(Throwable detail) {
        super(detail);
    }

    public ColumnFileException(String message, Throwable detail) {
        super(message, detail);
    }

}